﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

public class GridBoxGenerator : Editor {

	[MenuItem("Util/Generate Grid Box")]
	static void GeneatorGridBox() {
		Vector3 size = new Vector3(1.0f, 0.0f, 1.0f);
		Vector3 pivot = new Vector3(0.5f, 0.0f, 0.5f);
		var mesh = new Mesh();
		mesh.name = "GridBox";

		var vertices = new Vector3[8];
		vertices[0] = new Vector3(size.x * ( 1.0f - pivot.x ), -size.y * pivot.y, -size.z * pivot.z);
		vertices[1] = new Vector3(size.x * ( 1.0f - pivot.x ), -size.y * pivot.y, size.z * ( 1.0f - pivot.z ));
		vertices[2] = new Vector3(-size.x * pivot.x, -size.y * pivot.y, size.z * ( 1.0f - pivot.z ));
		vertices[3] = new Vector3(-size.x * pivot.x, -size.y * pivot.y, -size.z * pivot.z);
		vertices[4] = new Vector3(size.x * ( 1.0f - pivot.x ), size.y * ( 1.0f - pivot.y ), -size.z * pivot.z);
		vertices[5] = new Vector3(size.x * ( 1.0f - pivot.x ), size.y * ( 1.0f - pivot.y ), size.z * ( 1.0f - pivot.z ));
		vertices[6] = new Vector3(-size.x * pivot.x, size.y * ( 1.0f - pivot.y ), size.z * ( 1.0f - pivot.z ));
		vertices[7] = new Vector3(-size.x * pivot.x, size.y * ( 1.0f - pivot.y ), -size.z * pivot.z);

		var indices = new int[24] { 0, 1, 1, 2, 2, 3, 3, 0, 0, 4, 1, 5, 2, 6, 3, 7, 4, 5, 5, 6, 6, 7, 7, 4 };

		mesh.vertices = vertices;
		mesh.SetIndices(indices, MeshTopology.Lines, 0);
		AssetDatabase.CreateAsset(mesh, "Assets/grid_mesh.mesh");
		AssetDatabase.SaveAssets();
	}
}
